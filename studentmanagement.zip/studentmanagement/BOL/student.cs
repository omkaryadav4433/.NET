﻿namespace BOL
{
    public class student
    {

        private string id;
        private string name;
        private int age;
        public DateOnly bdate;
        public string course;
        private double fees;


        public student() { }    


        public student(string id, string name, int age, DateOnly bdate, string course, double fees)
        {
            this.id = id;
            this.name = name;
            this.age = age;
            this.bdate = bdate;
            this.course = course;
            this.fees = fees;
        }
        public string Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public DateOnly Bdate { get; set; }
        public string Course { get; set;}
        public double Fees { get; set; }



    }
   /* public override string ToString()
    {
        return string.Format("{0},{1},{2},{3},{4},{5}", id,);
    }*/
    }
